import React from 'react';
import CalendarioHorarios from './components/CalendarioHorarios';

function App() {
  return (
    <div className="App">
      <CalendarioHorarios />
    </div>
  );
}

export default App;