import React, { useState } from 'react';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction';
import axios from 'axios';

export default function CalendarioHorarios() {
  const [eventos, setEventos] = useState([]);

  const handleDateSelect = async (selectInfo) => {
    // Captura os dados básicos da seleção do utilizador no calendário
    const calendarApi = selectInfo.view.calendar;
    calendarApi.unselect(); 

    const confirmacao = window.confirm(`Deseja alocar um horário entre ${selectInfo.startStr} e ${selectInfo.endStr}?`);
    
    if (confirmacao) {
      // Futuramente, adicionaremos aqui um formulário modal para selecionar Turma, Disciplina e Professor.
      // De seguida, faremos o POST via axios para http://localhost:8080/api/teachers/horarios
      console.log("Horário selecionado para alocação.");
    }
  };

  return (
    <div style={{ padding: '20px', maxWidth: '1200px', margin: '0 auto' }}>
      <h2>Gestão de Horários e Turmas</h2>
      <FullCalendar
        plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
        headerToolbar={{
          left: 'prev,next today',
          center: 'title',
          right: 'dayGridMonth,timeGridWeek,timeGridDay'
        }}
        initialView="timeGridWeek"
        editable={true}
        selectable={true}
        selectMirror={true}
        dayMaxEvents={true}
        weekends={false} // Oculta sábados e domingos por padrão
        events={eventos}
        select={handleDateSelect}
        locale="pt"
      />
    </div>
  );
}